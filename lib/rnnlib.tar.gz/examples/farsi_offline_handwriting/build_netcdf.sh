#! /bin/bash
./farsi_chars.py -c filenames.txt farsi_chars.nc
